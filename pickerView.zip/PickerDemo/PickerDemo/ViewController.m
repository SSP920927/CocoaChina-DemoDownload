//
//  ViewController.m
//  PickerDemo
//
//  Created by dev1 on 15/12/15.
//  Copyright © 2015年 demo. All rights reserved.
//

#import "ViewController.h"
#import "UIView+RGSize.h"
#import "DBManager.h"
#import "Province.h"
#import "City.h"

@interface ViewController () <UIPickerViewDataSource,UIPickerViewDelegate>

@property (nonatomic, strong) UIView *maskView; // 遮罩层
@property (nonatomic, strong) UIView *supPickerView; // 装载pickerView
@property (nonatomic, strong) UIPickerView *myPickerView; // pickerView
@property (nonatomic, strong) UIView *smallView; // 装载button
@property (nonatomic, strong) Province *currentProvince;

@end

#define kScreen_Height      ([UIScreen mainScreen].bounds.size.height)
#define kScreen_Width       ([UIScreen mainScreen].bounds.size.width)
#define kScreen_Frame       (CGRectMake(0, 0 ,kScreen_Width,kScreen_Height))
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIButton *chooseCityButton = [UIButton buttonWithType:UIButtonTypeCustom];
    chooseCityButton.frame = CGRectMake(100, 100, 150, 50);
    [chooseCityButton setTitle:@"选择城市" forState:UIControlStateNormal];
    chooseCityButton.titleLabel.backgroundColor = [UIColor blackColor];
    [chooseCityButton addTarget:self action:@selector(chooseCity) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:chooseCityButton];
    
    [self initViews];
    [self getData];
    
}
- (void) getData
{
    [[DBManager sharedDBManager] openDB];
    [[DBManager sharedDBManager] disposeProData];
    [[DBManager sharedDBManager] closeDB];
    self.currentProvince = [[DBManager sharedDBManager].allData objectAtIndex:0];
}
- (void) initViews
{
    self.maskView = [[UIView alloc] initWithFrame:kScreen_Frame];
    self.maskView.backgroundColor = [UIColor blackColor];
    self.maskView.alpha = 0;
    [self.maskView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideMyPicker)]];
    
    self.supPickerView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreen_Height * 0.6, kScreen_Width, kScreen_Height * 0.45)];
    //self.supPickerView.width = kScreen_Width;
    self.supPickerView.backgroundColor = [UIColor whiteColor];
    
    self.myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 50, kScreen_Width, 200)];
    self.myPickerView.delegate = self;
    self.myPickerView.dataSource = self;
    [self.supPickerView addSubview:_myPickerView];
    
    self.smallView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 50)];
    self.smallView.backgroundColor = [UIColor colorWithRed:246.0/255.0 green:246.0/255.0 blue:246.0/255.0 alpha:1];
    
    UIButton *sureButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sureButton.frame = CGRectMake(kScreen_Width - 60, 0, 50, 50);
    sureButton.titleLabel.font = [UIFont systemFontOfSize: 22];
    [sureButton setTitle:@"确定" forState:UIControlStateNormal];
    [sureButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [sureButton addTarget:self action:@selector(makeSure) forControlEvents:UIControlEventTouchUpInside];
    [self.smallView addSubview:sureButton];
    
    UIButton *cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancleButton.frame = CGRectMake(10, 0, 50, 50);
    cancleButton.titleLabel.font = [UIFont systemFontOfSize: 22];
    [cancleButton setTitle:@"取消" forState:UIControlStateNormal];
    [cancleButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancleButton addTarget:self action:@selector(makeCancel) forControlEvents:UIControlEventTouchUpInside];
    [self.smallView addSubview:cancleButton];

}

- (void) chooseCity
{
    [self.supPickerView addSubview:self.smallView];
    [self.view addSubview:self.maskView];
    [self.view addSubview:self.supPickerView];
    self.maskView.alpha = 0;
    self.supPickerView.top = self.view.height;
    
    [UIView animateWithDuration:0.3 animations:^{
        self.maskView.alpha = 0.3;
        self.supPickerView.bottom = self.view.height;
    }];
}

- (void) hideMyPicker
{
    [UIView animateWithDuration:0.3 animations:^{
        self.maskView.alpha = 0;
        self.supPickerView.top = self.view.height;
    } completion:^(BOOL finished) {
        [self.maskView removeFromSuperview];
        [self.supPickerView removeFromSuperview];
    }];
}

- (void) makeSure
{
    NSLog(@"点击了确定");
    NSLog(@"%@",self.currentProvince);
    [self hideMyPicker];
}

- (void) makeCancel
{
    NSLog(@"点击了取消");
    [self hideMyPicker];
}

#pragma mark - UIPickerViewDelegate

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 2;
    
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    if (component == 0) {
        return [DBManager sharedDBManager].allData.count;
    }
    else
    {
        if (self.currentProvince.citys.count == 1) {
            return ((City *)[self.currentProvince.citys objectAtIndex:0]).zones.count;
        }else{
            return self.currentProvince.citys.count;
        }
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == 0) {
        return ((Province *)[[DBManager sharedDBManager].allData objectAtIndex:row]).proName;
    }
    else
    {
        if (self.currentProvince.citys.count == 1) {
            return [((City *)[self.currentProvince.citys objectAtIndex:0]).zones objectAtIndex:row];;
        }else{
            return ((City *)[self.currentProvince.citys objectAtIndex:row]).cityName;
        }
    }
}

- (void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSLog(@"选中%ld",(long)component);
    if (component == 0) {
        self.currentProvince = [[DBManager sharedDBManager].allData objectAtIndex:row];
        [pickerView reloadComponent:1];
        [pickerView selectRow:0 inComponent:1 animated:YES];
    }
}

@end
