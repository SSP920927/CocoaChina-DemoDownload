//
//  MZShapedButton.h
//  MZShapedButton
//
//  Created by zhangle on 15/12/4.
//  Copyright © 2015年 Machelle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MZShapedButton : UIButton

@property(nonatomic, strong) UIBezierPath *path;

@end
