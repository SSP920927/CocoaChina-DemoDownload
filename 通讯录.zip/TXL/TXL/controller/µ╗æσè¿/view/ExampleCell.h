//
//  ExampleCell.h
//  ExampleWithoutXib
//
//  Created by JLZ on 5/17/13.
//  Copyright (c) 2013 Jeremy Zedell. All rights reserved.
//

#import "JZSwipeCell.h"
@class  User;

@interface ExampleCell : JZSwipeCell
/**
 *  view颜色
 */
@property (weak, nonatomic) IBOutlet UIView *view_Color;
@property (weak, nonatomic) IBOutlet UILabel *label_Name;
@property (weak, nonatomic) IBOutlet UILabel *label_InView;//view里面的字
@property (weak, nonatomic) IBOutlet UILabel *label_Phone;//手机号码
@property (nonatomic,strong) User *user;

+ (NSString*)cellID;

@end
