//
//  ExampleCell.m
//  ExampleWithoutXib
//
//  Created by JLZ on 5/17/13.
//  Copyright (c) 2013 Jeremy Zedell. All rights reserved.
//

#import "ExampleCell.h"
#import "User.h"
#import <QuartzCore/QuartzCore.h>

//随机颜色
#define CHColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0];

@implementation ExampleCell

/**
 *  给我传值，把方法，赋值子啊这里做
 *
 *  @param user <#user description#>
 */
-(void)setUser:(User *)user{

    self.view_Color.layer.masksToBounds = YES;
    self.view_Color.layer.cornerRadius = 30.0;

    self.label_Name.text = user.name;
    self.label_Phone.text = user.tel;

    //view里面的字体
    NSString *string_InView = [user.name substringToIndex:1];
    self.label_InView.text = string_InView;//图片里面的字
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
	self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

        self = [[[NSBundle mainBundle] loadNibNamed:@"Exa" owner:nil options:nil]lastObject];

		// set the 4 icons for the 4 swipe types
		self.imageSet = SwipeCellImageSetMake([UIImage imageNamed:@"pac-man"], [UIImage imageNamed:@"blinky"], [UIImage imageNamed:@"ice-cream"], [UIImage imageNamed:@"balloons"]);
		self.colorSet = SwipeCellColorSetMake([UIColor greenColor], [UIColor redColor], [UIColor brownColor], [UIColor orangeColor]);


    }
    return self;
}

+ (NSString*)cellID
{

	return @"ExampleCell";
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
