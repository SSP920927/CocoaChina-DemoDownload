//
//  ViewController.h
//  BATableView
//
//  Created by abel on 14-5-7.
//  Copyright (c) 2014年 abel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

/**
 *  block 转换模型时，不能判断是不是 dic数据还是User数据
 *  没有 返回值 （有，nsstring  *(^judge_Model)(NSMutableArray *array); 有返回值，就要有指针）
 *  @param
 *
 *  @return <#return value description#>
 */
typedef void (^judge_Model)(NSMutableArray *array,NSMutableArray *sectionIndexs);

typedef enum{

    int_user,//是user的
    int_ordinary//普通的

}judge_User;

/**
 * 数据模型转化
 */
-(void) add_ArrayModel:(judge_Model)j_M judge:(judge_User)j_U;
@end
