//
//  ViewController.m
//  BATableView
//
//  Created by abel on 14-5-7.
//  Copyright (c) 2014年 abel. All rights reserved.
//

#import "ViewController.h"
#import "BATableViewKit/BATableView.h"
#import "PinYinForObjc.h"//拼音转化
#import "NSMutableArray+FilterElement.h"
#import "FollowGroupModel.h"
#import "FollowModel.h"
#import "JZSwipeCell.h"
#import "ExampleCell.h"
#import "AFNetworking.h"
#import "Util_GetHttp.h"
#import "Util_Path.h"
#import "model_User.h"
#import "AppDelegate.h"
#import "Util_Methods.h"
#import "User.h"
#import "SearchResultHandle.h"
#import "FollwTableViewCell.h"

@interface ViewController ()<BATableViewDelegate,JZSwipeCellDelegate,UISearchResultsUpdating,UISearchBarDelegate,UISearchControllerDelegate>
@property (nonatomic, strong) BATableView *contactTableView;
@property (nonatomic, strong) NSMutableArray * dataSource;


@property (nonatomic,strong) NSMutableArray *searchList; // 搜索结果的数组

//数据模型
/**
 *  数据源大数组
 */
@property (nonatomic,strong) NSMutableArray *dataArray;
@property (nonatomic,strong) NSMutableArray *array; // 数据源数组 分组和每个区的模型
@property (nonatomic,strong) NSMutableArray *sectionIndexs; // 放字母索引的数组

//SQLite
@property (nonatomic,strong) AppDelegate *myAppDelegate;

//搜索框
@property(strong, nonatomic) UISearchController *searchController;


@end

@implementation ViewController

-(AppDelegate *) myAppDelegate{


    if (_myAppDelegate == nil) {

        _myAppDelegate = [UIApplication sharedApplication].delegate;
    }
    return _myAppDelegate;
}

// 创建tableView
- (void) createTableView {

    self.contactTableView = [[BATableView alloc] initWithFrame:self.view.bounds];
    self.contactTableView.delegate = self;
    [self.view addSubview:self.contactTableView];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{

    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(NSMutableArray *)dataArray{

    if (_dataArray == nil) {

        _dataArray = [NSMutableArray array];
    }

    return _dataArray;
}

- (NSMutableArray *)searchList
{
    if (!_searchList) {
        _searchList = [NSMutableArray array];
    }
    return _searchList;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

   // [self add_ArrayModel];//数组模型转化
    self.automaticallyAdjustsScrollViewInsets = NO;

    [self add_SQLite_Judge];
    // [self add_GetHttp];
    [self add_Accept];
}

-(void) viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
}

/*************************** 基本方法 *************************/
#pragma mark -- 基本方法

/**
 *  添加搜索框
 */
-(void) add_Accept{

    _searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    _searchController.delegate = self;
    _searchController.searchResultsUpdater = self;
    _searchController.dimsBackgroundDuringPresentation = NO;
    _searchController.hidesNavigationBarDuringPresentation = NO;
    _searchController.searchBar.delegate = self;
    _searchController.searchBar.frame = CGRectMake(self.searchController.searchBar.frame.origin.x, self.searchController.searchBar.frame.origin.y, self.searchController.searchBar.frame.size.width, 44.0);
    _searchController.searchBar.placeholder = @"请输入搜索的的内容";
    _searchController.searchBar.searchBarStyle = UISearchBarStyleProminent;
    _searchController.searchBar.returnKeyType = UIReturnKeyDone;

    self.contactTableView.tableView.tableHeaderView  = self.searchController.searchBar;
}

/**
 *  访问服服务器
 */
-(void) add_GetHttp{

    NSString *string_Path_TXL = [Util_Path path_TXL];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //注意：默认数据是JSON，content-type也是JSON，responseObject是解析字典和数组，不是产生错误Code=-1016
    //解决:设置解析器为HTTP形式，下载回来是NSData
    // manager.responseSerializer = [AFCompoundResponseSerializer serializer];

    [manager GET:string_Path_TXL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {

       NSDictionary *dic = responseObject;
            //NSString *str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];

            NSNumber *nub_code = dic[@"code"];
            int int_code = [nub_code intValue];

            if (int_code > -1) {
    
                NSDictionary *dic_dataset = dic[@"dataset"];
                self.dataArray = [dic_dataset[@"rows"] mutableCopy];

                [self add_SQLite_Add:self.dataArray];

                //模型转化
                [self add_ArrayModel:^(NSMutableArray *array, NSMutableArray *sectionIndexs) {

                    for (NSDictionary *dic in array) {

                        NSString *string_Name =  dic[@"NAME"];
                        NSString *header = [PinYinForObjc chineseConvertToPinYinHead:string_Name];

                        [sectionIndexs addObject:header];
                    }
                } judge:int_ordinary];

            }
            else{
    
                NSLog( @"错了");
            }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error = %@",error);
    }];
 }

/**
 * 数据模型转化
 */
-(void) add_ArrayModel:(judge_Model)j_M judge:(judge_User)j_U{

    self.array = [NSMutableArray array];
    NSMutableArray *tempArray = [NSMutableArray array];

    self.sectionIndexs = [NSMutableArray array];

    j_M(self.dataArray,self.sectionIndexs);

    // 去除数组中相同的元素
    self.sectionIndexs = [self.sectionIndexs filterTheSameElement];
    // 数组排序
    [self.sectionIndexs sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSString *string1 = obj1;
        NSString *string2 = obj2;

        return [string1 compare:string2];
    }];

    // 将排序号的首字母数组取出 分成一个个组模型 和组模型下边的一个个 item
    for (NSString *string in self.sectionIndexs) {

        FollowGroupModel *group;
        if (j_U == int_user) {

            group = [FollowGroupModel getGroupsWith_User_Array:self.dataArray groupTitle:string];
        }
        else{

            group = [FollowGroupModel getGroupsWithArray:self.dataArray groupTitle:string];
        }

        //把每个标题一样的标题，放在一个数组里面
        NSMutableArray *array_Name = [NSMutableArray array];
        for (model_User *followModel in group.follows) {

            [array_Name addObject:followModel];
        }

        //在放到一个字典里面
        NSDictionary *dic_All = [NSDictionary dictionaryWithObjectsAndKeys:group.groupTitle,@"indexTitle",array_Name,@"data",nil];

        if ([dic_All[@"indexTitle"] isEqualToString:@"#"]) {

            // 默认 #开头的放在数组的最前边 后边才是 A-Z
            [tempArray insertObject:dic_All atIndex:0];
        }
        else{
            [tempArray addObject:dic_All];
        }
    }

    self.dataSource = tempArray;

    [self createTableView];
    [self.contactTableView.tableView reloadData];
}

/**
 * 把数据添加到数据库中
    1.查询数据，判断是不是有数据，没有就网络添加，后添加数据到数据库
    2.有数据，拿出数据，转数据模型
 */
-(void) add_SQLite_Judge{

    //查询数据
    NSFetchRequest *request = [[NSFetchRequest alloc] initWithEntityName:@"User"];

    NSError *error;
    //执行这个查询请求
    NSMutableArray *array = [[self.myAppDelegate.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];//把error这个指针给他

    if (array.count < 1) {

        [self add_GetHttp];
    }
    else{

        for (User *user in array) {

            NSMutableDictionary *dic = [NSMutableDictionary dictionary];
            dic[@"ADDRESS1"] = user.address1;
            dic[@"ADDRESS2"] = user.address2;
            dic[@"COMPANYTEL"] = user.companytel;
            dic[@"EMAIL"] = user.emall;
            dic[@"ID"] = [NSNumber numberWithInt:user.id];
            dic[@"MOBILE"] = user.mobile ;
            dic[@"NAME"] = user.name;
            dic[@"NXTEL"] = user.netel;
            dic[@"TEL"] = @"1";//user.tel;
            dic[@"TYPE"] = user.type;
            dic[@"ZIP"] = user.zip;

            [self.dataArray addObject:dic];
        }

        //数据模型转化
        [self add_ArrayModel:^(NSMutableArray *array, NSMutableArray *sectionIndexs) {

            for (NSDictionary *dic in array) {

                NSString *string_Name =  dic[@"NAME"];
                NSString *header = [PinYinForObjc chineseConvertToPinYinHead:string_Name];

                [sectionIndexs addObject:header];
            }

        } judge:int_ordinary];

    }
}

/**
 *  删除功能
 *  @param array <#array description#>
 */
-(void) add_SQLite_Delete:(NSArray *) array{
    User *user = array[0];
    [self.myAppDelegate.managedObjectContext deleteObject:user];
    [self.myAppDelegate saveContext];
}

/**
 * SQLite 查询
 *  @param string <#string description#>
 *
 *  @return <#return value description#>
 */
-(NSMutableArray *) add_SQLite_Select:(NSString *)string{

    NSManagedObjectContext *context = self.myAppDelegate.managedObjectContext;
    // 限定查询结果的数量
    //setFetchLimit
    // 查询的偏移量
    //setFetchOffset

    //查询数据
    NSFetchRequest *request = [[NSFetchRequest alloc] initWithEntityName:@"User"];

    NSPredicate * qcmd ;

    if (![string isEqualToString:@""]) {
        NSString *name = @"name";
        NSString *attributeValue = [NSString stringWithFormat:@"*%@*",string];
        qcmd = [NSPredicate predicateWithFormat:@"%K like %@",name,attributeValue];
    }
    [request setPredicate:qcmd];
    NSError *error;

    return  [[context executeFetchRequest:request error:&error] mutableCopy];//可变数组
}

/**
 *  把数据添加到SQLite里面
 *  @param array <#array description#>
 */
-(void) add_SQLite_Add:(NSMutableArray *)array{

    if ((int)array.count > 0) {

        //创建实体描述对象
        NSEntityDescription *description = [NSEntityDescription entityForName:@"User" inManagedObjectContext:self.myAppDelegate.managedObjectContext];

            for (NSDictionary *dic in array) {
             //建立一个模型对象
             User *user = [[User alloc] initWithEntity:description insertIntoManagedObjectContext:self.myAppDelegate.managedObjectContext];

             user.id = [dic[@"id"] intValue];
             user.address1 = [Util_Methods util_judge_NSnull:dic[@"ADDRESS1"]];
             user.address2 = [Util_Methods util_judge_NSnull:dic[@"ADDRESS2"]];
             user.companytel = [Util_Methods util_judge_NSnull:dic[@"COMPANYTEL"]];
             user.emall = [Util_Methods util_judge_NSnull:dic[@"EMAIL"]];
             user.mobile = [NSString stringWithFormat:@"%@",dic[@"MOBILE"]];
             user.name = [Util_Methods util_judge_NSnull:dic[@"NAME"]];
             user.netel = [Util_Methods util_judge_NSnull:dic[@"NXTEL"]];
             user.tel = [NSString stringWithFormat:@"%@",dic[@"TEL"]];
             user.type = [NSString stringWithFormat:@"%@",dic[@"TYPE"]];
             user.zip = [Util_Methods util_judge_NSnull:dic[@"ZIP"]];

             //对数据管理中的进行永久存储
             [self.myAppDelegate saveContext];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 *  打电话功能
 */
-(void) add_MakePhoneNSString:(NSString *)string{

    UIWebView *callWebview =[[UIWebView alloc] init];

    //通用格式
    NSString *string_Tel = [NSString stringWithFormat:@"tel://%@",string];
    //电话号码
    NSURL *telURL =[NSURL URLWithString:string_Tel];// 貌似tel:// 或者 tel: 都行
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    //记得添加到view上
    [self.view addSubview:callWebview];
}

/**
 *  发短信功能
 *
 *  @param string <#string description#>
 */
-(void) add_TextingNSString:(NSString *)string{

    NSString *string_Tel = [NSString stringWithFormat:@"sms://%@",string];

     [[UIApplication sharedApplication]openURL:[NSURL URLWithString:string_Tel]];//发短信
}

//
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.contactTableView.tableView endEditing:YES];
}

/*************************** 代理方法 *************************/
#pragma mark -- 代理方法
#pragma mark - UITableViewDataSource（索引）
- (NSArray *) sectionIndexTitlesForABELTableView:(BATableView *)tableView {
    NSMutableArray * indexTitles = [NSMutableArray array];
    for (NSDictionary * sectionDictionary in self.dataSource) {
        [indexTitles addObject:sectionDictionary[@"indexTitle"]];
    }
    return indexTitles;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.dataSource[section][@"indexTitle"];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.dataSource[section][@"data"] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    ExampleCell *cell = [tableView dequeueReusableCellWithIdentifier:[ExampleCell cellID]];
    if (!cell){

        cell = [[ExampleCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:[ExampleCell cellID]];
    }
    
    cell.user = self.dataSource[indexPath.section][@"data"][indexPath.row];

    cell.delegate = self;

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ExampleCell *cell = [[ExampleCell alloc] init];//(JZSwipeCell*)[self.contactTableView.tableView cellForRowAtIndexPath:indexPath];
    [cell triggerSwipeWithType:(JZSwipeType)((arc4random() % 4) + 1)];

}

/**
 *
 * row的高度
 *  @param indexPath <#indexPath description#>
 *
 *  @return <#return value description#>
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 90;
}



#pragma mark - JZSwipeCellDelegate methods(滑动删除)


- (void)swipeCell:(JZSwipeCell*)cell triggeredSwipeWithType:(JZSwipeType)swipeType
{

    [self.contactTableView.tableView reloadData];
}

- (void)triggerSwipeWithType:(JZSwipeType)type{


}

/**
 *  这个是滑动代理
 *
 *  @param cell <#cell description#>
 *  @param from <#from description#>
 *  @param to   <#to description#>
 */
- (void)swipeCell:(JZSwipeCell *)cell swipeTypeChangedFrom:(JZSwipeType)from to:(JZSwipeType)to{

    //switch 里面不能有指针，因为他不能，垃圾回收。
    switch (to) {

        case JZSwipeTypeLongLeft:

            [self add_MakePhoneNSString:@"10086"];
            break;

        case JZSwipeTypeLongRight:

            [self add_TextingNSString:@"10086"];
            break;

        default:
            break;
    }
}

#pragma mark -- 搜索代理
#pragma mark - UISearchBarDelegate
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController{

     NSString *string_Search = [self.searchController.searchBar text];


    if (![string_Search isEqualToString:@""]) {

        [self.dataArray removeAllObjects];//所有数据删除
        self.dataArray= [self add_SQLite_Select:string_Search];

        NSLog(@"%d",(int)self.dataArray.count);
        //数据模型转化
        [self add_ArrayModel:^(NSMutableArray *array, NSMutableArray *sectionIndexs) {

            for (User *user in array) {

                NSLog(@"%@",user.name);
                NSString *string_Name =  user.name;
                NSString *header = [PinYinForObjc chineseConvertToPinYinHead:string_Name];

                [sectionIndexs addObject:header];
            }

        } judge:int_user];
    }

}


@end
