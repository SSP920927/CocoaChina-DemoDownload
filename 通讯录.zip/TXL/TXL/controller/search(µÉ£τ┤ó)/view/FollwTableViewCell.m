//
//  FollwTableViewCell.m
//  剧能玩2.1
//
//  Created by 大兵布莱恩特  on 15/11/11.
//  Copyright © 2015年 大兵布莱恩特 . All rights reserved.
//

#import "FollwTableViewCell.h"

@implementation FollwTableViewCell

- (void)awakeFromNib {
    self.headImageView.layer.cornerRadius = 25;
    self.headImageView.layer.masksToBounds = YES;
}

@end
