//
//  FollwTableViewCell.h
//  剧能玩2.1
//
//  Created by 大兵布莱恩特  on 15/11/11.
//  Copyright © 2015年 大兵布莱恩特 . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZSwipeCell.h"

@interface FollwTableViewCell : JZSwipeCell
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *nickNmaeLabel;

@end
