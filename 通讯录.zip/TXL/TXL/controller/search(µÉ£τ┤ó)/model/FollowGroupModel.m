//
//  FollowGroupModel.m
//  剧能玩2.1
//
//  Created by 大兵布莱恩特  on 15/11/11.
//  Copyright © 2015年 大兵布莱恩特 . All rights reserved.
//

#import "FollowGroupModel.h"
#import "PinYinForObjc.h"
#import "FollowModel.h"
#import "model_User.h"
#import "User.h"


@implementation FollowGroupModel

//+ (instancetype)getGroupsWithArray:(NSMutableArray*)dataArray groupTitle:(NSString*)title
//{
//    NSMutableArray *tempArray = [NSMutableArray array];
//    FollowGroupModel *group = [[FollowGroupModel alloc] init];
//    for (NSString *str in dataArray)
//    {
//        NSString *header = [PinYinForObjc chineseConvertToPinYinHead:str];
//        if ([header isEqualToString:title])
//        {
//            FollowModel *followM = [[FollowModel alloc] init];
//            followM.img_Url = @"";
//            followM.nickname = str;
//            [tempArray addObject:followM];
//        }
//    }
//    group.groupTitle = title;
//    group.follows = tempArray;
//    return group;
//}


+ (instancetype)getGroupsWithArray:(NSMutableArray*)dataArray groupTitle:(NSString*)title{

        NSMutableArray *tempArray = [NSMutableArray array];
        FollowGroupModel *group = [[FollowGroupModel alloc] init];

        for (NSDictionary *dic in dataArray){

            NSString *string_Name = dic[@"NAME"];
            NSString *header = [PinYinForObjc chineseConvertToPinYinHead:string_Name];
            if ([header isEqualToString:title]){

                model_User *user = [[model_User alloc] init];

                user.address1 =[[self alloc]judge_NSNull_NSString:dic[@"ADDRESS1"]];
                user.address2 = [[self alloc]judge_NSNull_NSString:dic[@"ADDRESS2"]];
                user.companytel = [[self alloc]judge_NSNull_NSString:dic[@"COMPANYTEL"]];
                user.emall = [[self alloc]judge_NSNull_NSString:dic[@"EMAIL"]];
                user.id = [dic[@"ID"] intValue];
                user.mobile = [NSString stringWithFormat:@"%@",dic[@"MOBILE"]];
                user.name = dic[@"NAME"];
                user.netel = [NSString stringWithFormat:@"%@",dic[@"NXTEL"]];
                user.tel =  [NSString stringWithFormat:@"%@",dic[@"TEL"]];
                user.type = [NSString stringWithFormat:@"%@",dic[@"TYPE"]];
                user.zip = [[self alloc]judge_NSNull_NSString:dic[@"ZIP"]];

                [tempArray addObject:user];
            }
        }

        group.groupTitle = title;
        group.follows = tempArray;
        return group;
}

/**
 *  这个是解析—User
 *
 *  @param dataArray <#dataArray description#>
 *  @param title     <#title description#>
 *
 *  @return <#return value description#>
 */
+ (instancetype)getGroupsWith_User_Array:(NSMutableArray*)dataArray groupTitle:(NSString*)title{

    NSMutableArray *tempArray = [NSMutableArray array];
    FollowGroupModel *group = [[FollowGroupModel alloc] init];

    for (User *usera in dataArray){

        NSString *string_Name = usera.name;
        NSString *header = [PinYinForObjc chineseConvertToPinYinHead:string_Name];
        if ([header isEqualToString:title]){

            model_User *user = [[model_User alloc] init];

            user.address1 =[[self alloc]judge_NSNull_NSString:usera.address1];
            user.address2 = [[self alloc]judge_NSNull_NSString:usera.address2];
            user.companytel = [[self alloc]judge_NSNull_NSString:usera.companytel];
            user.emall = [[self alloc]judge_NSNull_NSString:usera.emall];
            user.id = usera.id;
            user.mobile = [NSString stringWithFormat:@"%@",usera.mobile];
            user.name = usera.name;
            user.netel = [NSString stringWithFormat:@"%@",usera.netel];
            user.tel =  [NSString stringWithFormat:@"%@",usera.tel];
            user.type = [NSString stringWithFormat:@"%@",usera.type];
            user.zip = [[self alloc]judge_NSNull_NSString:usera.zip];

            [tempArray addObject:user];
        }
    }

    group.groupTitle = title;
    group.follows = tempArray;
    return group;
}

/**
 *  字典nsnull判断
 *
 *  @return <#return value description#>
 */
-(NSString *)  judge_NSNull_NSString:(NSString *)string{

    NSString *string_NSNull = @"";
    if (![string isEqual:[NSNull null]]) {

        string_NSNull = string;
    }
    return string_NSNull;
}
@end
