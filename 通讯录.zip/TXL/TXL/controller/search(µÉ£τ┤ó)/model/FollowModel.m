//
//  FollowModel.m
//  剧能玩2.1
//
//  Created by 大兵布莱恩特  on 15/11/11.
//  Copyright © 2015年 大兵布莱恩特  All rights reserved.
//

#import "FollowModel.h"

@implementation FollowModel

@end
