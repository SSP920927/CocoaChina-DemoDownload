//
//  Util_Methods.h
//  TXL
//
//  Created by 虞海飞 on 15/12/8.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Util_Methods : NSObject

/**
 *
 *判断是不是nsnull
 *  @param string <#string description#>
 *
 *  @return <#return value description#>
 */
+(NSString *) util_judge_NSnull:(NSString *)string;

@end
