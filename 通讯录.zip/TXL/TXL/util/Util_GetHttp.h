//
//  Util_GetHttp.h
//  TXL
//
//  Created by 虞海飞 on 15/12/7.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

@interface Util_GetHttp : NSObject

@property (nonatomic,strong) NSDictionary *dic;

/**
 * 访问，服务器
 *
 *  @return <#return value description#>
 */
-(NSDictionary *) getHttpPath:(NSString *)path;
@end
