//
//  Util_GetHttp.m
//  TXL
//
//  Created by 虞海飞 on 15/12/7.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import "Util_GetHttp.h"

@implementation Util_GetHttp

/**
 * 访问，服务器
 *
 *  @return <#return value description#>
 */
-(NSDictionary *) getHttpPath:(NSString *)path{

    static NSDictionary *dic;
    //定义AFNetworking管理
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //注意：默认数据是JSON，content-type也是JSON，responseObject是解析字典和数组，不是产生错误Code=-1016
    //解决:设置解析器为HTTP形式，下载回来是NSData
    // manager.responseSerializer = [AFCompoundResponseSerializer serializer];

    [manager GET:path parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {

        dic = responseObject;
//        //NSString *str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"%@",responseObject);
//
//        NSNumber *nub_code = dic[@"code"];
//        int int_code = [nub_code intValue];
//
//        if (int_code > -1) {
//
//            NSDictionary *dic_dataset = dic[@"dataset"];
//            NSArray *array = dic_dataset[@"rows"];
//
//            NSLog(@"%d",(int)array.count);
//        }else{
//
//            NSLog( @"错了");
//        }


    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error = %@",error);
    }];
    
    return dic;
}

@end
