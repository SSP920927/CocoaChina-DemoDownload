//
//  Util_Path.h
//  TXL
//
//  Created by 虞海飞 on 15/12/7.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Util_Path : NSObject

/**
 *  通讯录
 *
 *  @return <#return value description#>
 */
+(NSString *) path_TXL;

@end
