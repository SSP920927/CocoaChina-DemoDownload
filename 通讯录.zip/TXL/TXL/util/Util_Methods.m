//
//  Util_Methods.m
//  TXL
//
//  Created by 虞海飞 on 15/12/8.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import "Util_Methods.h"

/**
 *  常用方法
 */
@implementation Util_Methods

/**
 *
 *判断是不是nsnull
 *  @param string <#string description#>
 *
 *  @return <#return value description#>
 */
+(NSString *) util_judge_NSnull:(NSString *)string{

    NSString *string_NSNull = @"";
    if (![string isEqual:[NSNull null]]) {

        string_NSNull = string;
    }
    return string_NSNull;
}

@end
