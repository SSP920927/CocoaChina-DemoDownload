//
//  User+CoreDataProperties.m
//  TXL
//
//  Created by 虞海飞 on 15/12/7.
//  Copyright © 2015年 虞海飞. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "User+CoreDataProperties.h"

@implementation User (CoreDataProperties)

@dynamic id;
@dynamic type;
@dynamic name;
@dynamic address1;
@dynamic address2;
@dynamic mobile;
@dynamic tel;
@dynamic zip;
@dynamic emall;
@dynamic companytel;
@dynamic netel;

@end
