//
//  User.m
//  TXL
//
//  Created by 虞海飞 on 15/12/7.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import "User.h"

@implementation User

// Insert code here to add functionality to your managed object subclass

@end
