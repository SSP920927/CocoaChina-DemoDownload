//
//  model_User.m
//  TXL
//
//  Created by 虞海飞 on 15/12/8.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import "model_User.h"

@implementation model_User

@end
