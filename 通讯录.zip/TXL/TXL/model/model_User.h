//
//  model_User.h
//  TXL
//
//  Created by 虞海飞 on 15/12/8.
//  Copyright © 2015年 虞海飞. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface model_User : NSObject

@property (nonatomic,assign) int id;
@property (nullable, nonatomic, copy) NSString *type;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *address1;
@property (nullable, nonatomic, copy) NSString *address2;
@property (nullable, nonatomic, copy) NSString *mobile;
@property (nullable, nonatomic, copy) NSString *tel;
@property (nullable, nonatomic, copy) NSString *zip;
@property (nullable, nonatomic, copy) NSString *emall;
@property (nullable, nonatomic, copy) NSString *companytel;
@property (nullable, nonatomic, copy) NSString *netel;

@end
