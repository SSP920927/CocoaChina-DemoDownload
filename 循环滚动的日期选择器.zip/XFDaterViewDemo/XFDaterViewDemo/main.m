//
//  main.m
//  XFDaterViewDemo
//
//  Created by 许晓菲 on 16/6/30.
//  Copyright © 2016年 BigFly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
