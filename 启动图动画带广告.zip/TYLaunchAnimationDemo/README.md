# TYLaunchAnimation
launching image or view Animation,UIView Category,easy to use.

启动图动画，带广告，封装成UIView分类，直接使用。

