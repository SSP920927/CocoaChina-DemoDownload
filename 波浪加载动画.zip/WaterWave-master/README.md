# WaterWave
iOS上的波浪动画。  
  
动画效果如下：  
  
![image](http://ww4.sinaimg.cn/mw690/8f7a6fe0gw1f6lb4ym7ovg207002z3ym.gif)  
  
详细介绍在[这里](http://summertreee.github.io/blog/2016/08/07/dong-hua-huang-jin-da-dang-cadisplaylink-and-cashapelayer/)

