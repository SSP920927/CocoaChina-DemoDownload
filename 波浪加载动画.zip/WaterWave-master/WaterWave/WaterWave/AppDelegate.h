//
//  AppDelegate.h
//  WaterWave
//
//  Created by liangwei on 16/7/7.
//  Copyright © 2016年 liangwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

