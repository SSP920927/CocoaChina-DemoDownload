//
//  AppDelegate.h
//  DDCategoryDemo
//
//  Created by Daredos on 15/12/10.
//  Copyright (c) 2015年 BlueMoon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

