/**
 *******************************************************
 *                                                      *
 * 感谢您的支持， 如果下载的代码在使用过程中出现BUG或者其他问题    *
 *                                                         *
 * 您可以发邮件到 asiosldh@163.com 或者 QQ 872304636            *
 *
 
 !!<< 随便总结了在项目中使用到的一些分类,以后会完善...
  *******************************************************
 */


#import "ViewController.h"
#import "DDKitCategory.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.dd_x = 1;
    self.view.dd_y = 1;
    self.view.dd_width = 1;
    self.view.dd_cornerRadius = 1;
    
    // ... 想用什么就加什么
}

@end
