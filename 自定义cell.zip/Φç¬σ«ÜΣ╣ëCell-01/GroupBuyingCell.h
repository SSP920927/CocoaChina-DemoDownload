//
//  GroupBuyingCell.h
//  自定义Cell-01
//
//  Created by zlx on 15/11/17.
//  Copyright © 2015年 zlx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GroupBuyingData;

@interface GroupBuyingCell : UITableViewCell

@property (nonatomic,strong) GroupBuyingData *groupbuying;
//@property (nonatomic,strong) NSArray *array;

+ (instancetype)GroupBuyingWithTableView:(UITableView *)tableview;



@end
