//
//  ViewController.m
//  自定义Cell-01
//
//  Created by zlx on 15/11/17.
//  Copyright © 2015年 zlx. All rights reserved.
//
#import "GroupBuyingCell.h"
#import "ViewController.h"
#import "GroupBuyingData.h"
@interface ViewController () <UITableViewDataSource>
@property (nonatomic,strong) NSArray *arrayList;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation ViewController


- (BOOL)prefersStatusBarHidden{


    return YES;

}


-(NSArray *)arrayList{

    if (_arrayList ==nil ) {
        
        _arrayList = [GroupBuyingData GroupBuyingList];
        
        
    }
    return _arrayList;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight = 80;
    self.tableView.dataSource = self;
    NSLog(@"%@",self.arrayList);
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.arrayList.count;

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    //创建可重用的Cell
    GroupBuyingCell *cell = [GroupBuyingCell GroupBuyingWithTableView:tableView];
    
    
    //2 设置cell内部的子控件
   GroupBuyingData *zlx = self.arrayList[indexPath.row];
    cell.groupbuying = zlx;
    
    //3 返回
    return cell;


}























@end
