//
//  GroupBuyingData.h
//  自定义Cell-01
//
//  Created by zlx on 15/11/17.
//  Copyright © 2015年 zlx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupBuyingData : NSObject
@property (nonatomic,copy) NSString *buyCount;
@property (nonatomic,copy) NSString *icon;
@property (nonatomic,copy) NSString *price;
@property (nonatomic,copy) NSString *title;

- (instancetype) initWithDic:(NSDictionary *)dic;
+ (instancetype) GroupBuyingWithDic:(NSDictionary *)dic;
+ (NSArray *)GroupBuyingList;



@end
