//
//  footView.m
//  自定义Cell-01
//
//  Created by zlx on 15/11/18.
//  Copyright © 2015年 zlx. All rights reserved.
//

#import "footView.h"
@interface footView()
@property (weak, nonatomic) IBOutlet UIButton *footview;

- (IBAction)loadmoreClink;




@end
@implementation footView



- (IBAction)loadmoreClink {
}
@end
