//
//  GroupBuyingData.m
//  自定义Cell-01
//
//  Created by zlx on 15/11/17.
//  Copyright © 2015年 zlx. All rights reserved.
//

#import "GroupBuyingData.h"

@implementation GroupBuyingData

- (instancetype) initWithDic:(NSDictionary *)dic{

    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dic];
    }


    return self;

}

+ (instancetype) GroupBuyingWithDic:(NSDictionary *)dic{


    return [[self alloc]initWithDic:dic];


}


+ (NSArray *)GroupBuyingList{

   //获取plist
    NSString *path = [[NSBundle mainBundle]pathForResource:@"tgs" ofType:@"plist"];
    
    NSArray *dicArray = [NSArray arrayWithContentsOfFile:path];
    
    NSMutableArray *Marray = [NSMutableArray array];
    
    for (NSDictionary *dic in dicArray) {
        
        GroupBuyingData *data = [[GroupBuyingData alloc]initWithDic:dic];
        
        [Marray addObject:data];
        
        
    }

    return Marray;

}


@end
