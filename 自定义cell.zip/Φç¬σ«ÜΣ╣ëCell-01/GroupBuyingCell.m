//
//  GroupBuyingCell.m
//  自定义Cell-01
//
//  Created by zlx on 15/11/17.
//  Copyright © 2015年 zlx. All rights reserved.
//

#import "GroupBuyingCell.h"
#import "GroupBuyingData.h"


//定义一个类扩展，定义私有的属性

@interface GroupBuyingCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *titleView;
@property (weak, nonatomic) IBOutlet UILabel *priceView;
@property (weak, nonatomic) IBOutlet UILabel *buyCountView;
@end
@implementation GroupBuyingCell
   //创建可重用的Cell

+ (instancetype)GroupBuyingWithTableView:(UITableView *)tableview{
    
    static NSString *reuseId = @"zlx";
    
    GroupBuyingCell *cell = [tableview dequeueReusableCellWithIdentifier:reuseId];
    
    if (cell == nil) {
        
        cell = [[[NSBundle mainBundle]loadNibNamed:@"GroupBuyingCell" owner:nil options:nil]lastObject];
        
        
    }

    return cell;

}

- (void)setGroupbuying:(GroupBuyingData *)groupbuying{

    _groupbuying = groupbuying;
    
    self.iconView.image = [UIImage imageNamed:groupbuying.icon];
    self.titleView.text = groupbuying.title;
    self.priceView.text = [NSString stringWithFormat:@"￥ %@",groupbuying.price];
    self.buyCountView.text = [NSString stringWithFormat:@"%@ 人已购买",groupbuying.buyCount];
    

}


    










@end
