//
//  main.m
//  LCVoiceHud
//
//  Created by 郭历成 on 13-6-21.
//  Copyright (c) 2013年 Wuxiantai Developer Team. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LCVoiceHudAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LCVoiceHudAppDelegate class]));
    }
}
