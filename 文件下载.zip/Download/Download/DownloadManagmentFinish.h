//
//  DownloadManagmentFinish.h
//  Download
//
//  Created by 陈伟捷 on 15/11/12.
//  Copyright © 2015年 chenweijie. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DownloadManagmentFinish : NSObject

@property(nonatomic, copy)NSString *url;

@property(nonatomic, copy)NSString *savePath;

@property(nonatomic, assign)double time;

@end
