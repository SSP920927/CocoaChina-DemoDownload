//
//  ViewController.h
//  清除缓存
//
//  Created by strj on 15/12/4.
//  Copyright © 2015年 strj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

